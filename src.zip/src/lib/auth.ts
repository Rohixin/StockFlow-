// src/lib/auth.ts
// Utility functions for authentication (e.g., JWT handling, session management)
export const getToken = (): string | null => {
    // Implement logic to retrieve token from localStorage or cookies
    return localStorage.getItem('authToken');
};

export const setToken = (token: string) => {
    localStorage.setItem('authToken', token);
};

export const removeToken = () => {
    localStorage.removeItem('authToken');
};

export const isAuthenticated = (): boolean => {
    return !!getToken();
};

// More complex auth logic would go here, possibly integrating with NextAuth.js