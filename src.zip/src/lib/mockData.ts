// my-stock-dashboard/src/lib/mockData.ts

interface StockData {
  symbol: string;
  companyName: string;
  latestPrice: number;
  change: number;
  changePercent: number;
  marketCap: number;
  peRatio: number;
  fiftyTwoWeekHigh: number;
  fiftyTwoWeekLow: number;
}

interface WatchlistItem {
  symbol: string;
  companyName: string;
  price: number;
  change: number;
  changePercent: number;
}

export const getMockStockData = (): StockData[] => [
  {
    symbol: 'AAPL',
    companyName: 'Apple Inc.',
    latestPrice: 170.12,
    change: 1.50,
    changePercent: 0.89,
    marketCap: 2700000000000,
    peRatio: 28.5,
    fiftyTwoWeekHigh: 185.00,
    fiftyTwoWeekLow: 130.00,
  },
  {
    symbol: 'MSFT',
    companyName: 'Microsoft Corp.',
    latestPrice: 420.50,
    change: -2.10,
    changePercent: -0.50,
    marketCap: 3100000000000,
    peRatio: 35.2,
    fiftyTwoWeekHigh: 430.00,
    fiftyTwoWeekLow: 280.00,
  },
  {
    symbol: 'GOOGL',
    companyName: 'Alphabet Inc.',
    latestPrice: 175.80,
    change: 0.75,
    changePercent: 0.43,
    marketCap: 2200000000000,
    peRatio: 25.1,
    fiftyTwoWeekHigh: 180.00,
    fiftyTwoWeekLow: 120.00,
  },
  {
    symbol: 'AMZN',
    companyName: 'Amazon.com Inc.',
    latestPrice: 185.20,
    change: 3.10,
    changePercent: 1.70,
    marketCap: 1900000000000,
    peRatio: 50.0,
    fiftyTwoWeekHigh: 190.00,
    fiftyTwoWeekLow: 130.00,
  },
  {
    symbol: 'NVDA',
    companyName: 'NVIDIA Corp.',
    latestPrice: 1100.00,
    change: 15.00,
    changePercent: 1.38,
    marketCap: 2700000000000,
    peRatio: 70.0,
    fiftyTwoWeekHigh: 1150.00,
    fiftyTwoWeekLow: 400.00,
  },
  {
    symbol: 'TSLA',
    companyName: 'Tesla Inc.',
    latestPrice: 180.00,
    change: -5.00,
    changePercent: -2.70,
    marketCap: 580000000000,
    peRatio: 45.0,
    fiftyTwoWeekHigh: 220.00,
    fiftyTwoWeekLow: 140.00,
  },
  {
    symbol: 'META',
    companyName: 'Meta Platforms Inc.',
    latestPrice: 480.00,
    change: -1.50,
    changePercent: -0.31,
    marketCap: 1200000000000,
    peRatio: 30.0,
    fiftyTwoWeekHigh: 500.00,
    fiftyTwoWeekLow: 280.00,
  },
  {
    symbol: 'NFLX',
    companyName: 'Netflix Inc.',
    latestPrice: 650.00,
    change: 2.00,
    changePercent: 0.31,
    marketCap: 280000000000,
    peRatio: 55.0,
    fiftyTwoWeekHigh: 670.00,
    fiftyTwoWeekLow: 450.00,
  },
];

export const getMockWatchlistData = (): WatchlistItem[] => [
  {
    symbol: 'AAPL',
    companyName: 'Apple Inc.',
    price: 170.12,
    change: 1.50,
    changePercent: 0.89,
  },
  {
    symbol: 'MSFT',
    companyName: 'Microsoft Corp.',
    price: 420.50,
    change: -2.10,
    changePercent: -0.50,
  },
  {
    symbol: 'GOOGL',
    companyName: 'Alphabet Inc.',
    price: 175.80,
    change: 0.75,
    changePercent: 0.43,
  },
];