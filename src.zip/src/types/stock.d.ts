// src/types/stock.d.ts
// TypeScript interfaces for stock-related data
export interface StockDataPoint {
    Date: string;
    Open: number;
    High: number;
    Low: number;
    Close: number;
    Volume: number;
    // Add technical indicators here if you process them on frontend
    SMA7?: number;
    EMA12?: number;
    BB_upper?: number;
    BB_lower?: number;
    RSI?: number;
    MACD?: number;
    MACD_Signal?: number;
}

export interface ForecastDataPoint {
    ds: string; // Datestamp
    yhat: number; // Predicted value
    yhat_lower?: number; // Lower bound of confidence interval
    yhat_upper?: number; // Upper bound of confidence interval
}

export interface CompanyInfo {
    longName?: string;
    sector?: string;
    industry?: string;
    exchange?: string;
    currency?: string;
    country?: string;
    marketCap?: number;
    trailingPE?: number;
    forwardPE?: number;
    dividendYield?: number;
    beta?: number;
    fiftyTwoWeekHigh?: number;
    fiftyTwoWeekLow?: number;
    averageDailyVolume10Day?: number;
    sharesOutstanding?: number;
    fullTimeEmployees?: number;
    // ... add more as needed
}

export interface MarketOverviewItem {
    name: string;
    value: string;
    change: string;
    type: string; // e.g., 'index', 'commodity'
    img: string; // URL to an image
}

export interface WatchlistItem {
    symbol: string;
    name: string;
    price: string;
    change: string;
    img: string; // URL to an image
}