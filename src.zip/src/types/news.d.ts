// src/types/news.d.ts
// TypeScript interfaces for news-related data
export interface NewsArticle {
    title: string;
    url: string;
    description: string;
    sentiment: 'Positive' | 'Negative' | 'Neutral';
    score: number; // Sentiment score
    source: string;
    publishedAt: string; // ISO string or similar
    // ... add more as needed
}