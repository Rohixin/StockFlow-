// src/utils/dataUtils.ts
// Frontend utility functions for data transformation, formatting, etc.

export const formatCurrency = (value: number, currency: string = '₹'): string => {
    return `${currency}${value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

export const formatPercentage = (value: number): string => {
    return `${value.toFixed(2)}%`;
};

export const calculateDailyChange = (latest: number, previous: number): { change: number; percentage: number } => {
    const change = latest - previous;
    const percentage = (change / previous) * 100;
    return { change, percentage };
};

// Add other data utility functions as needed (e.g., indicator calculations for client-side display if not done on backend)