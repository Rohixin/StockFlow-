// src/components/dashboard/Watchlist.tsx
// This component would display the user's personalized watchlist.
// Its content is currently in Dashboard.tsx under "My Watchlist".

import React from 'react';

interface WatchlistProps {
  data: any[]; // Data for watchlist stocks
}

const Watchlist: React.FC<WatchlistProps> = ({ data }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {data.map((stock, index) => (
        <div key={index} className="p-6 rounded-xl card-neumorphic flex flex-col hover:scale-[1.02] transition-transform duration-200 border border-cyan-blue-200/10">
          <div className="flex items-center mb-4">
            <img src={stock.img} alt={stock.symbol} className="w-12 h-12 rounded-full mr-4 object-cover shadow-md border border-cyan-blue-200/20" />
            <div>
              <h3 className="text-xl font-semibold text-light-gray">{stock.symbol}</h3>
              <p className="text-sm text-gray-400">{stock.name}</p>
            </div>
          </div>
          <div className="flex justify-between items-end">
            <p className="text-2xl font-bold text-cyan-blue-300">₹{stock.price}</p>
            <p className={`text-lg font-semibold ${stock.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>{stock.change}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Watchlist;