// my-stock-dashboard/src/components/dashboard/Dashboard.tsx
'use client'; // This directive is crucial for client-side functionality

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import dynamic from 'next/dynamic'; // For client-side only component loading

// --- IMPORTANT: PASTE YOUR ALPHA VANTAGE API KEY HERE ---
// Get your free key from: https://www.alphavantage.co/support/#api-key
const ALPHA_VANTAGE_API_KEY ='U5WQ23V1XH95BE8S';

// Dynamically import StockChart to ensure it's client-side rendered and avoids SSR issues
const StockChart = dynamic(
  () => import('../charts/StockChart'), // <--- Verify this path: '../charts/StockChart'
  {
    ssr: false, // This is the critical part: Render this component ONLY on the client
    loading: () => ( // Optional: Show a loading state while the chart component is being fetched
      <div className="flex items-center justify-center h-96 bg-charcoal-800 p-6 rounded-xl shadow-xl glass-effect border border-cyan-blue-200/20">
        <svg className="animate-spin h-10 w-10 text-cyan-blue-300" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <span className="ml-4 text-light-gray">Loading Chart...</span>
      </div>
    ),
  }
);

// --- Helper Functions for Mock Data ---
const getRandom = (min: number, max: number) => Math.random() * (max - min) + min;

// --- Interface for Stock Data Points ---
// This matches the format expected by StockChart and what Alpha Vantage returns
interface StockDataPoint {
  Date: string; // Will be the full timestamp string (e.g., "2025-06-07 14:30:00")
  Open: number;
  High: number;
  Low: number;
  Close: number;
  Volume: number;
}

// --- Alpha Vantage Data Fetching Functions ---

// Helper to fetch daily data (used as a fallback or for long history)
const fetchDailyStockData = async (symbol: string): Promise<StockDataPoint[]> => {
    try {
        const dailyResponse = await fetch(
            `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=${symbol}&outputsize=compact&apikey=${ALPHA_VANTAGE_API_KEY}`
        );
        const dailyData = await dailyResponse.json();

        if (dailyData["Error Message"]) {
            throw new Error(dailyData["Error Message"]);
        }
        if (dailyData["Time Series (Daily)"]) {
            const formattedDailyData: StockDataPoint[] = Object.entries(dailyData["Time Series (Daily)"])
                .map(([date, values]: [string, any]) => ({
                    Date: date, // Just the date string (e.g., "2025-06-07")
                    Open: parseFloat(values["1. open"]),
                    High: parseFloat(values["2. high"]),
                    Low: parseFloat(values["3. low"]),
                    Close: parseFloat(values["4. close"]),
                    Volume: parseInt(values["6. volume"]), // Volume is "6. volume" for daily adjusted
                }))
                .reverse(); // Alpha Vantage daily data is reverse chronological; reverse to get oldest first
            return formattedDailyData;
        } else {
            throw new Error(`Could not fetch any daily data for ${symbol}.`);
        }
    } catch (dailyError) {
        console.error("Error fetching daily data fallback:", dailyError);
        return []; // Return empty array on error
    }
};

// Main function to fetch stock data (attempts intraday first, then daily fallback)
const fetchStockData = async (symbol: string): Promise<StockDataPoint[]> => {
  console.log(`Attempting to fetch data for: ${symbol}`);
  try {
    // Try to get 1-minute intraday data for near real-time updates
    const intradayResponse = await fetch(
      `https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=${symbol}&interval=1min&outputsize=full&apikey=${ALPHA_VANTAGE_API_KEY}`
    );
    const intradayData = await intradayResponse.json();

    if (intradayData["Error Message"]) {
      console.error(`Alpha Vantage API Error for ${symbol} (Intraday):`, intradayData["Error Message"]);
      // Fallback to daily data if intraday returns an error
      return await fetchDailyStockData(symbol);
    }

    if (intradayData["Time Series (1min)"]) {
      const timeSeries = intradayData["Time Series (1min)"];
      const formattedData: StockDataPoint[] = Object.entries(timeSeries)
        .map(([timeString, values]: [string, any]) => ({
          Date: timeString, // Full timestamp string (e.g., "2025-06-07 14:30:00")
          Open: parseFloat(values["1. open"]),
          High: parseFloat(values["2. high"]),
          Low: parseFloat(values["3. low"]),
          Close: parseFloat(values["4. close"]),
          Volume: parseInt(values["5. volume"]),
        }))
        .reverse(); // Alpha Vantage returns most recent first, reverse to show oldest to newest

      // Filter out points before today if we are getting "full" data from intraday
      const today = new Date().toISOString().split('T')[0];
      return formattedData.filter(d => d.Date.startsWith(today));

    } else {
      // If no 1-min data (e.g., weekend/holiday/after market hours), try daily
      console.warn(`No 1-min intraday data for ${symbol}. Falling back to daily.`);
      return await fetchDailyStockData(symbol);
    }
  } catch (error) {
    console.error("Error fetching data:", error);
    // Ultimate fallback to daily if any network or parsing error occurs
    return await fetchDailyStockData(symbol);
  }
};


// Function to simulate AI model forecast (Keeping this as mock as real AI forecasting is complex)
const generateForecast = async (model: string, data: StockDataPoint[], years: number) => {
  console.log(`Generating mock ${model} forecast for ${years} years`);
  return new Promise<any[]>(resolve => {
    setTimeout(() => {
      if (!data || data.length === 0) {
        resolve([]);
        return;
      }
      const lastDataPoint = data[data.length - 1];
      const lastClose = lastDataPoint.Close;
      const forecast: { ds: string; yhat: number; yhat_lower: number; yhat_upper: number }[] = Array.from({ length: years * 365 }, (_, i) => {
        const date = new Date(lastDataPoint.Date);
        date.setDate(date.getDate() + i + 1); // Start forecast from the day after the last historical data point

        // Simulate a trend with some noise and increasing uncertainty
        const yhat = lastClose * (1 + (0.00005 * i) + getRandom(-0.0001, 0.0001) * i) + getRandom(-5, 5);
        const uncertainty = i * 0.005 + 10; // Uncertainty grows over time
        const yhat_lower = yhat - getRandom(0, uncertainty);
        const yhat_upper = yhat + getRandom(0, uncertainty);

        return {
          ds: date.toISOString().split('T')[0], // Date string
          yhat: parseFloat(yhat.toFixed(2)), // Predicted value
          yhat_lower: parseFloat(yhat_lower.toFixed(2)), // Lower bound of confidence interval
          yhat_upper: parseFloat(yhat_upper.toFixed(2)) // Upper bound of confidence interval
        };
      });
      resolve(forecast);
    }, 1500); // Simulate network delay
  });
};

// --- Mock News Sentiment (will be replaced by backend call later) ---
const fetchNewsSentiment = async (companyName: string) => {
  console.log(`Fetching mock news sentiment for: ${companyName}`);
  return new Promise<any[]>(resolve => {
    setTimeout(() => {
      const mockNews = [
        { title: `${companyName} Q1 Earnings Beat Expectations`, url: 'https://www.ft.com/markets', description: `Company ${companyName} reports strong first quarter results, surpassing analyst forecasts. This indicates robust operational efficiency and market demand.`, sentiment: 'Positive', score: 0.8, source: 'Financial Times', publishedAt: '2025-06-05' },
        { title: `${companyName} Faces Regulatory Scrutiny`, url: 'https://www.reuters.com/business', description: `New government regulations may significantly impact ${companyName}'s future operations and profitability, leading to investor concerns.`, sentiment: 'Negative', score: -0.6, source: 'Reuters', publishedAt: '2025-06-04' },
        { title: `Analyst Maintains Neutral Rating for ${companyName}`, url: 'https://www.bloomberg.com/markets', description: `A prominent brokerage firm reiterates its neutral stance on ${companyName} stock, citing balanced growth prospects and potential risks.`, sentiment: 'Neutral', score: 0.1, source: 'Bloomberg', publishedAt: '2025-06-03' },
        { title: `${companyName} Announces Revolutionary Product`, url: 'https://techcrunch.com/', description: `Exciting new product line from ${companyName} expected to disrupt the market and significantly boost sales in the coming quarters.`, sentiment: 'Positive', score: 0.9, source: 'TechCrunch', publishedAt: '2025-06-02' },
        { title: `${companyName} Stock Dips Amid Broader Market Volatility`, url: 'https://www.wsj.com/markets', description: `Broader market correction and geopolitical tensions drag down ${companyName} shares despite strong company fundamentals.`, sentiment: 'Negative', score: -0.7, source: 'Wall Street Journal', publishedAt: '2025-06-01' },
        { title: `${companyName} Forms Strategic Alliance`, url: 'https://www.businesswire.com/portal/site/home/', description: `${companyName} forms strategic alliance with a key industry player, expanding its global market footprint.`, sentiment: 'Positive', score: 0.75, source: 'Business Wire', publishedAt: '2025-05-30' },
        { title: `${companyName} CEO Discusses Future Strategy`, url: 'https://www.forbes.com/business/', description: `In a recent interview, ${companyName}'s CEO outlined ambitious plans for innovation and growth, instilling confidence.`, sentiment: 'Positive', score: 0.6, source: 'Forbes', publishedAt: '2025-05-29' },
      ];
      resolve(mockNews);
    }, 800); // Simulate network delay
  });
};

// Mock Company Info Data - updated with Alpha Vantage compatible symbols and default prices
const getMockCompanyInfo = (symbol: string) => {
  const symbolUpper = symbol.toUpperCase();

  // Prices below are just for consistent mocking, actual prices will come from API
  if (symbolUpper.includes('RELIANCE.BSE')) {
    return {
      companyName: 'Reliance Industries Ltd.',
      sector: 'Diversified Conglomerate',
      industry: 'Petroleum, Retail, Telecom',
      marketCap: '₹2,500,000 Cr',
      trailingPE: '28.7x',
      dividendYield: '0.8%',
      fiftyTwoWeekHigh: '₹3,200.00',
      fiftyTwoWeekLow: '₹2,100.00',
      avgVolume: '2.3M',
      lastClose: 1443.00 // Close to actual June 6, 2025 value
    };
  } else if (symbolUpper.includes('TCS.BSE')) {
    return {
      companyName: 'Tata Consultancy Services Ltd.',
      sector: 'Information Technology',
      industry: 'IT Services & Consulting',
      marketCap: '₹1,400,000 Cr',
      trailingPE: '32.5x',
      dividendYield: '1.2%',
      fiftyTwoWeekHigh: '₹4,200.00',
      fiftyTwoWeekLow: '₹3,000.00',
      avgVolume: '1.5M',
      lastClose: 3950.00
    };
  } else if (symbolUpper.includes('INFY.BSE')) { // Added Infosys for example
    return {
      companyName: 'Infosys Ltd.',
      sector: 'Information Technology',
      industry: 'IT Services & Consulting',
      marketCap: '₹650,000 Cr',
      trailingPE: '28.0x',
      dividendYield: '1.5%',
      fiftyTwoWeekHigh: '₹1,700.00',
      fiftyTwoWeekLow: '₹1,300.00',
      avgVolume: '1.0M',
      lastClose: 1550.00
    };
  }
  else if (symbolUpper.includes('AAPL')) {
    return {
      companyName: 'Apple Inc.',
      sector: 'Technology',
      industry: 'Consumer Electronics',
      marketCap: '$3,200B',
      trailingPE: '30.0x',
      dividendYield: '0.5%',
      fiftyTwoWeekHigh: '$220.00',
      fiftyTwoWeekLow: '$150.00',
      avgVolume: '70.0M',
      lastClose: 170.25
    };
  } else if (symbolUpper.includes('GOOG')) {
    return {
      companyName: 'Alphabet Inc.',
      sector: 'Technology',
      industry: 'Internet Services',
      marketCap: '$2,500B',
      trailingPE: '28.0x',
      dividendYield: '0.0%',
      fiftyTwoWeekHigh: '$180.00',
      fiftyTwoWeekLow: '$110.00',
      avgVolume: '45.0M',
      lastClose: 175.80
    };
  } else if (symbolUpper.includes('MSFT')) {
    return {
      companyName: 'Microsoft Corp.',
      sector: 'Technology',
      industry: 'Software & Cloud Services',
      marketCap: '$3,300B',
      trailingPE: '35.0x',
      dividendYield: '0.7%',
      fiftyTwoWeekHigh: '$460.00',
      fiftyTwoWeekLow: '$320.00',
      avgVolume: '35.0M',
      lastClose: 425.10
    };
  } else if (symbolUpper.includes('TSLA')) {
    return {
      companyName: 'Tesla Inc.',
      sector: 'Automotive',
      industry: 'Electric Vehicles & Energy',
      marketCap: '$580B',
      trailingPE: '60.0x', // Higher P/E for growth stock
      dividendYield: '0.0%',
      fiftyTwoWeekHigh: '$280.00',
      fiftyTwoWeekLow: '$140.00',
      avgVolume: '100.0M',
      lastClose: 180.50
    };
  }
  // Default fallback for any other symbol
  return {
    companyName: `${symbol.split('.')[0]} Corp.`,
    sector: 'Technology',
    industry: 'Software',
    marketCap: '₹1,000,000 Cr',
    trailingPE: '25.0x',
    dividendYield: '1.0%',
    fiftyTwoWeekHigh: '₹1,000.00',
    fiftyTwoWeekLow: '₹500.00',
    avgVolume: '1.0M',
    lastClose: 750 // Default mock price
  };
};

interface DashboardProps {
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  // Set default symbol to an Alpha Vantage compatible one for India
  const [stockSymbol, setStockSymbol] = useState('RELIANCE.BSE');
  const [compareStockSymbol, setCompareStockSymbol] = useState('');
  const [forecastYears, setForecastYears] = useState(2);
  const [modelChoice, setModelChoice] = useState('Prophet'); // Default AI model
  const [selectedIndicators, setSelectedIndicators] = useState<string[]>([]);
  const [stockData, setStockData] = useState<StockDataPoint[] | null>(null);
  const [compareStockData, setCompareStockData] = useState<StockDataPoint[] | null>(null);
  const [forecastData, setForecastData] = useState<any[] | null>(null);
  const [newsSentiment, setNewsSentiment] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [showWelcome, setShowWelcome] = useState(true);

  // Effect to hide welcome screen
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowWelcome(false);
    }, 4000); // Show welcome for 4 seconds
    return () => clearTimeout(timer);
  }, []);

  // Effect to manage dark mode class on document element
  useEffect(() => {
    if (typeof window !== 'undefined') { // Ensure running in browser
      if (darkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [darkMode]);

  // Use useCallback to memoize the handleAnalyze function.
  const handleAnalyze = useCallback(async (symbolToAnalyze: string) => {
    setLoading(true);
    try {
      if (symbolToAnalyze !== stockSymbol) {
        setStockSymbol(symbolToAnalyze);
      }

      // Fetch historical data for main stock using Alpha Vantage
      const mainStockData = await fetchStockData(symbolToAnalyze);
      setStockData(mainStockData);

      // Fetch historical data for comparison stock if symbol is provided
      if (compareStockSymbol) {
        const compStockData = await fetchStockData(compareStockSymbol);
        setCompareStockData(compStockData);
      } else {
        setCompareStockData(null); // Clear compare data if no symbol
      }

      // Generate forecast data using the selected model, only if main data is available
      if (mainStockData.length > 0) {
        const forecast = await generateForecast(modelChoice, mainStockData, forecastYears);
        setForecastData(forecast);
      } else {
        setForecastData(null);
      }

      // --- Using MOCK NEWS SENTIMENT for now ---
      const companyNameForNews = getMockCompanyInfo(symbolToAnalyze).companyName;
      const sentiment = await fetchNewsSentiment(companyNameForNews);
      setNewsSentiment(sentiment);

    } catch (error) {
      console.error("Analysis failed:", error);
      setStockData(null);
      setCompareStockData(null);
      setForecastData(null);
      setNewsSentiment(null);
      alert('Error performing analysis. Please check your console for details.'); // Use alert only for user feedback
    } finally {
      setLoading(false);
    }
  }, [compareStockSymbol, forecastYears, modelChoice, stockSymbol]);

  // Initial data fetch and re-fetch when stockSymbol changes or every minute for "real-time" effect
  useEffect(() => {
    const loadData = async () => {
      await handleAnalyze(stockSymbol); // Call handleAnalyze to fetch data for main and compare symbols
    };

    loadData(); // Load data immediately on component mount

    // Set up polling to refresh data every minute (be mindful of API limits!)
    // Alpha Vantage free tier has limits (e.g., 5 requests/minute). Adjust if you hit limits.
    const intervalId = setInterval(loadData, 60 * 1000); // 60 seconds * 1000 ms = 1 minute

    return () => clearInterval(intervalId); // Clear interval when component unmounts
  }, [stockSymbol, handleAnalyze]); // Dependencies

  // Define a hardcoded watchlist with mock data (useMemo for optimization)
  const mockWatchlist = useMemo(() => [
    { symbol: 'AAPL', name: 'Apple Inc.', price: 170.25, change: '+1.1%', changeIsPositive: true, img: 'https://placehold.co/40x40/000000/ffffff/png?text=AAPL' },
    { symbol: 'GOOG', name: 'Alphabet Inc.', price: 175.80, change: '+0.9%', changeIsPositive: true, img: 'https://placehold.co/40x40/4285F4/ffffff/png?text=GOOG' },
    { symbol: 'MSFT', name: 'Microsoft Corp.', price: 425.10, change: '-0.2%', changeIsPositive: false, img: 'https://placehold.co/40x40/217346/ffffff/png?text=MSFT' },
    { symbol: 'TSLA', name: 'Tesla Inc.', price: 180.50, change: '-1.5%', changeIsPositive: false, img: 'https://placehold.co/40x40/E82127/ffffff/png?text=TSLA' },
    { symbol: 'RELIANCE.BSE', name: 'Reliance Industries Ltd.', price: 1443.00, change: '+0.75%', changeIsPositive: true, img: 'https://placehold.co/40x40/0A2C6C/ffffff/png?text=RIL' }, // Updated symbol and mock price
    { symbol: 'TCS.BSE', name: 'Tata Consultancy Services Ltd.', price: 3950.20, change: '-0.15%', changeIsPositive: false, img: 'https://placehold.co/40x40/003C66/ffffff/png?text=TCS' }, // Updated symbol
    { symbol: 'INFY.BSE', name: 'Infosys Ltd.', price: 1550.00, change: '+0.5%', changeIsPositive: true, img: 'https://placehold.co/40x40/0A2C6C/ffffff/png?text=INFY' }, // Added another Indian stock
  ], []);

  // Define mock market overview data (useMemo for optimization)
  const mockMarketOverview = useMemo(() => [
    { name: 'S&P 500', value: '5,350.50', change: '+0.5%', type: 'index', img: 'https://placehold.co/40x40/3abff8/ffffff/png?text=S%26P', symbol: '^GSPC' },
    { name: 'NASDAQ', value: '17,100.20', change: '+0.8%', type: 'index', img: 'https://placehold.co/40x40/f472b6/ffffff/png?text=NAS', symbol: '^IXIC' },
    { name: 'Dow Jones', value: '38,700.10', change: '-0.1%', type: 'index', img: 'https://placehold.co/40x40/22c55e/ffffff/png?text=DOW', symbol: '^DJI' },
    { name: 'Crude Oil', value: '$75.20', change: '+1.2%', type: 'commodity', img: 'https://placehold.co/40x40/6b7280/ffffff/png?text=OIL', symbol: 'CL=F' },
    { name: 'Gold', value: '$2,350.00', change: '-0.3%', type: 'commodity', img: 'https://placehold.co/40x40/ef4444/ffffff/png?text=GOLD', symbol: 'GC=F' },
  ], []);

  // Helper to render stock snapshot cards for a given stock data
  const renderStockSnapshot = (symbol: string, currentStockData: StockDataPoint[] | null) => {
    const info = getMockCompanyInfo(symbol);
    let lastClosePrice: number | null = info.lastClose; // Initialize as number or null

    // If actual historical data is available, use its last close price for more accuracy
    if (currentStockData && currentStockData.length > 0) {
      lastClosePrice = currentStockData[currentStockData.length - 1].Close;
    }

    // Ensure lastClosePrice is a valid number for calculations and display
    const displayPrice = typeof lastClosePrice === 'number' && !isNaN(lastClosePrice) ? lastClosePrice : null;

    let dailyChange: string = 'N/A';
    let dailyPercentChange: string = 'N/A';
    let isPositive = true;

    if (currentStockData && currentStockData.length >= 2) {
      const latest = currentStockData[currentStockData.length - 1].Close;
      const prev = currentStockData[currentStockData.length - 2].Close;
      const change = latest - prev;
      const percent = ((change / prev) * 100);
      dailyChange = change.toFixed(2);
      dailyPercentChange = percent.toFixed(2);
      isPositive = change >= 0;
    } else if (displayPrice !== null) { // Use displayPrice to ensure it's a valid number for calculations
        // Fallback for mock data if historical data isn't enough for 2 days
        // Simulate a small, random daily change based on the mock lastClosePrice
        const simulatedChange = (displayPrice / 100) * (getRandom(-1.0, 1.0)); // +/- 1%
        dailyChange = simulatedChange.toFixed(2);
        dailyPercentChange = `${((simulatedChange / displayPrice) * 100).toFixed(2)}%`;
        isPositive = simulatedChange >= 0;
    }


    return (
      <div className="flex-1 min-w-[280px] p-4">
        <h3 className="text-xl font-bold mb-4 text-cyan-blue-300 drop-shadow">{symbol.split('.')[0]} Snapshot</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl text-center card-neumorphic border border-cyan-blue-200/10">
            <p className="text-sm text-gray-400 mb-2">Latest Close Price</p>
            <p className="text-2xl font-bold text-cyan-blue-300">₹{displayPrice !== null ? displayPrice.toFixed(2) : 'N/A'}</p>
          </div>
          <div className="p-4 rounded-xl text-center card-neumorphic border border-cyan-blue-200/10">
            <p className="text-sm text-gray-400 mb-2">Daily Change</p>
            <p className={`text-2xl font-bold ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
              ₹{dailyChange} ({dailyPercentChange}%)
            </p>
          </div>
          <div className="p-4 rounded-xl text-center card-neumorphic border border-cyan-blue-200/10">
            <p className="text-sm text-gray-400 mb-2">Daily High (Mock)</p>
            <p className="text-2xl font-bold text-cyan-blue-300">₹{displayPrice !== null ? (displayPrice * getRandom(1.005, 1.015)).toFixed(2) : 'N/A'}</p>
          </div>
          <div className="p-4 rounded-xl text-center card-neumorphic border border-cyan-blue-200/10">
            <p className="text-sm text-gray-400 mb-2">Daily Low (Mock)</p>
            <p className="text-2xl font-bold text-cyan-blue-300">₹{displayPrice !== null ? (displayPrice * getRandom(0.985, 0.995)).toFixed(2) : 'N/A'}</p>
          </div>
        </div>
      </div>
    );
  };

  // Helper to render company info for a given symbol
  const renderCompanyInfo = (symbol: string) => {
    const info = getMockCompanyInfo(symbol);
    return (
      <div className="flex-1 min-w-[300px] p-4">
        <h3 className="text-xl font-bold mb-4 text-cyan-blue-300 drop-shadow">Company Info for {info.companyName}</h3>
        <div className="text-base text-light-gray">
          <p className="mb-2"><strong className="text-cyan-blue-300">Company Name:</strong> {info.companyName}</p>
          <p className="mb-2"><strong className="text-cyan-blue-300">Sector:</strong> {info.sector}</p>
          <p className="mb-2"><strong className="text-cyan-blue-300">Industry:</strong> {info.industry}</p>
          <p className="mb-2"><strong className="text-cyan-blue-300">Market Cap:</strong> {info.marketCap}</p>
          <p className="mb-2"><strong className="text-cyan-blue-300">Trailing P/E:</strong> {info.trailingPE}</p>
          <p className="mb-2"><strong className="text-cyan-blue-300">Dividend Yield:</strong> {info.dividendYield}</p>
          <p className="mb-2"><strong className="text-cyan-blue-300">52 Week High:</strong> {info.fiftyTwoWeekHigh}</p>
          <p className="mb-2"><strong className="text-cyan-blue-300">52 Week Low:</strong> {info.fiftyTwoWeekLow}</p>
          <p className="mb-2"><strong className="text-cyan-blue-300">Avg. Volume (10d):</strong> {info.avgVolume}</p>
        </div>
      </div>
    );
  };

  // Helper for sentiment styling
  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'Positive':
        return 'text-green-500';
      case 'Negative':
        return 'text-red-500';
      case 'Neutral':
        return 'text-gray-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className={`min-h-screen flex ${darkMode ? 'bg-dark-navy text-light-gray' : 'bg-white text-gray-800'} transition-colors duration-300`}>
      <aside className={`fixed top-0 left-0 h-full w-64 p-6 shadow-xl transform ${darkMode ? 'bg-charcoal-800' : 'bg-white'} transition-all duration-300 ease-in-out z-20 overflow-y-auto border-r border-cyan-blue-200/10`}>
        <h2 className="text-2xl font-bold mb-6 text-cyan-blue-300 drop-shadow">📈 Stock Analyzer</h2>

        <div className="flex items-center justify-between mb-8 p-3 rounded-xl bg-dark-navy card-neumorphic border border-cyan-blue-200/10">
          <span className="text-light-gray text-base font-medium mr-2">{darkMode ? '🌙 Dark Mode' : '🌞 Light Mode'}</span>
          <label htmlFor="theme-toggle" className="toggle-switch">
            <input
              id="theme-toggle"
              type="checkbox"
              checked={darkMode}
              onChange={() => setDarkMode(!darkMode)}
            />
            <span className="toggle-slider"></span>
          </label>
        </div>

        <div className="mb-5">
          <label htmlFor="stock-symbol" className="block text-sm font-medium mb-2 text-cyan-blue-200">Main Stock (e.g., RELIANCE.BSE)</label>
          <input
            id="stock-symbol"
            type="text"
            className="w-full p-2.5 rounded-lg neumorphic-input bg-dark-navy text-light-gray placeholder-gray-500 text-sm"
            value={stockSymbol}
            onChange={(e) => setStockSymbol(e.target.value.toUpperCase())}
            placeholder="RELIANCE.BSE" // Changed placeholder
          />
        </div>

        <div className="mb-5">
          <label htmlFor="forecast-years" className="block text-sm font-medium mb-2 text-cyan-blue-200">Forecast Years: <span className="text-light-gray font-semibold">{forecastYears}</span></label>
          <input
            id="forecast-years"
            type="range"
            min="1"
            max="5"
            value={forecastYears}
            onChange={(e) => setForecastYears(parseInt(e.target.value))}
            className="w-full h-2.5 bg-dark-navy rounded-lg appearance-none cursor-pointer range-xl neumorphic-input"
            style={{accentColor: '#f472b6'}}
          />
        </div>

        <div className="mb-5">
          <label htmlFor="model-choice" className="block text-sm font-medium mb-2 text-cyan-blue-200">Prediction Model</label>
          <select
            id="model-choice"
            className="w-full p-2.5 rounded-lg neumorphic-input bg-dark-navy text-light-gray text-sm"
            value={modelChoice}
            onChange={(e) => setModelChoice(e.target.value)}
          >
            <option value="Prophet">Prophet</option>
            <option value="XGBoost">XGBoost</option>
            {/* Add more AI models here if needed */}
          </select>
        </div>

        <div className="mb-5">
          <label htmlFor="indicators" className="block text-sm font-medium mb-2 text-cyan-blue-200">Overlay Indicators</label>
          <select
            id="indicators"
            multiple
            className="w-full p-2.5 rounded-lg neumorphic-input h-28 bg-dark-navy text-light-gray text-sm"
            value={selectedIndicators}
            onChange={(e) =>
              setSelectedIndicators(
                Array.from(e.target.selectedOptions, (option) => option.value)
              )
            }
          >
            <option value="None">None</option>
            <option value="SMA (7-Day)">SMA (7-Day)</option>
            <option value="EMA (12-Day)">EMA (12-Day)</option>
            <option value="Bollinger Bands">Bollinger Bands</option>
            <option value="RSI">RSI</option>
            <option value="MACD">MACD</option>
          </select>
        </div>

        <div className="mb-6">
          <label htmlFor="compare-symbol" className="block text-sm font-medium mb-2 text-cyan-blue-200">Compare With (Optional, e.g., TCS.BSE)</label>
          <input
            id="compare-symbol"
            type="text"
            className="w-full p-2.5 rounded-lg neumorphic-input bg-dark-navy text-light-gray placeholder-gray-500 text-sm"
            value={compareStockSymbol}
            onChange={(e) => setCompareStockSymbol(e.target.value.toUpperCase())}
            placeholder="TCS.BSE" // Changed placeholder
          />
        </div>

        <button
          onClick={() => handleAnalyze(stockSymbol)} // Trigger analysis for the current main stock symbol
          className="w-full py-3.5 rounded-lg text-white font-semibold neumorphic-button bg-gradient-to-r from-cyan-blue-300 to-pink-300 hover:from-cyan-blue-400 hover:to-pink-400 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-cyan-blue-300 focus:ring-opacity-75"
          disabled={loading}
        >
          {loading ? (
            <svg className="animate-spin h-5 w-5 text-white inline-block mr-2" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : '📊'} {loading ? 'Analyzing...' : 'Analyze Stock Data'}
        </button>

        <button
          onClick={onLogout}
          className="w-full py-3.5 mt-4 rounded-lg text-white font-semibold neumorphic-button bg-gradient-to-r from-pink-300 to-red-500 hover:from-pink-400 hover:to-red-600 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:-shadow-lg focus:outline-none focus:ring-2 focus:ring-pink-300 focus:ring-opacity-75"
        >
          Logout
        </button>
      </aside>

      <main className="flex-1 ml-64 p-8 bg-gradient-to-br from-dark-navy to-charcoal-800 animate-fade-in">
        <h1 className="text-4xl lg:text-5xl font-extrabold mb-8 text-cyan-blue-300 tracking-tight drop-shadow-lg">
          Advanced Stock Dashboard <span className="text-pink-300">Unleashed</span>
        </h1>

        {showWelcome && (
          <div className="fixed inset-0 flex items-center justify-center bg-dark-navy/90 z-50 animate-fade-in">
            <div className="bg-charcoal-800 p-10 rounded-2xl shadow-2xl glass-effect border border-cyan-blue-200/30 text-center animate-pop-in">
              <h2 className="text-5xl font-extrabold text-cyan-blue-300 mb-4 animate-pulse-subtle">Welcome Back!</h2>
              <p className="text-xl text-light-gray mb-6">Your insights are waiting.</p>
              <svg className="animate-bounce mx-auto h-12 w-12 text-pink-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
              </svg>
              <p className="text-gray-500 text-sm mt-4">Preparing your personalized market view...</p>
            </div>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center p-12 bg-charcoal-800 rounded-xl shadow-xl glass-effect border border-cyan-blue-200/20 mb-12 animate-pulse-subtle">
            <svg className="animate-spin h-10 w-10 text-cyan-blue-300 mb-4" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <span className="text-light-gray text-xl font-medium">Loading data and generating insights...</span>
            <p className="text-gray-500 text-sm mt-2">This might take a moment as complex models are running.</p>
          </div>
        )}

        {/* Render content only when not loading and stockData is available */}
        {!loading && stockData && (
          <>
            <section className="mb-12 animate-slide-up">
              <h2 className="text-3xl font-bold mb-6 text-cyan-blue-300 drop-shadow">🌍 Global Market Overview</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {mockMarketOverview.map((item, index) => (
                  <a
                    key={index}
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setStockSymbol(item.symbol); // Click to analyze this market item
                    }}
                    className="block"
                  >
                    <div className="p-4 rounded-xl card-neumorphic flex items-center space-x-3 transition-transform duration-200 hover:scale-[1.03] border border-cyan-blue-200/10 h-full">
                      <img src={item.img} alt={item.name} className="w-10 h-10 rounded-full mr-3 object-cover shadow-sm" />
                      <div>
                        <p className="text-sm font-semibold text-light-gray leading-tight">{item.name}</p>
                        <p className="text-lg font-bold text-cyan-blue-300">{item.value}</p>
                        <p className={`text-xs ${item.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>{item.change}</p>
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </section>

            <section className="mb-12 animate-slide-up">
              <h2 className="text-3xl font-bold mb-6 text-cyan-blue-300 drop-shadow">⭐ My Watchlist</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {mockWatchlist.map((stock, index) => (
                  <a
                    key={index}
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setStockSymbol(stock.symbol); // Click to analyze this stock
                    }}
                    className="block"
                  >
                    <div className="p-6 rounded-xl card-neumorphic flex flex-col hover:scale-[1.02] transition-transform duration-200 border border-cyan-blue-200/10 h-full">
                      <div className="flex items-center mb-4">
                        <img src={stock.img} alt={stock.symbol} className="w-12 h-12 rounded-full mr-4 object-cover shadow-md border border-cyan-blue-200/20" />
                        <div>
                          <h3 className="text-xl font-semibold text-light-gray">{stock.symbol}</h3>
                          <p className="text-sm text-gray-400">{stock.name}</p>
                        </div>
                      </div>
                      <div className="flex justify-between items-end">
                        <p className="text-2xl font-bold text-cyan-blue-300">₹{stock.price.toFixed(2)}</p>
                        <p className={`text-lg font-semibold ${stock.changeIsPositive ? 'text-green-500' : 'text-red-500'}`}>{stock.change}</p>
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </section>

            {/* Current Market Snapshot for BOTH stocks */}
            <section className="mb-12 animate-slide-up">
              <h2 className="text-3xl font-bold mb-6 text-cyan-blue-300 drop-shadow">💰 Current Stock Snapshot</h2>
              <div className="flex flex-wrap lg:flex-nowrap gap-6 p-8 rounded-xl card-neumorphic border border-cyan-blue-200/20">
                {renderStockSnapshot(stockSymbol, stockData)}
                {compareStockData && compareStockSymbol && renderStockSnapshot(compareStockSymbol, compareStockData)}
              </div>
            </section>

            {/* Company & Stock Key Information for BOTH stocks */}
            <section className="mb-12 animate-slide-up">
              <h2 className="text-3xl font-bold mb-6 text-cyan-blue-300 drop-shadow">📋 Company & Key Information</h2>
              <div className="flex flex-wrap lg:flex-nowrap gap-6 p-8 rounded-xl card-neumorphic border border-cyan-blue-200/20">
                {renderCompanyInfo(stockSymbol)}
                {compareStockData && compareStockSymbol && renderCompanyInfo(compareStockSymbol)}
              </div>
            </section>

            {/* Historical Price & Volume Chart */}
            <section className="mb-12 animate-slide-up">
              <h2 className="text-3xl font-bold mb-6 text-cyan-blue-300 drop-shadow">📈 Historical Price & Volume</h2>
              <div className="bg-charcoal-800 p-6 rounded-xl shadow-xl glass-effect border border-cyan-blue-200/20">
                {stockData ? (
                  <StockChart
                    data={stockData}
                    compareData={compareStockData}
                    forecastData={forecastData}
                    indicators={selectedIndicators}
                    mainSymbol={stockSymbol}
                    compareSymbol={compareStockSymbol}
                    darkMode={darkMode}
                  />
                ) : (
                  <p className="text-light-gray text-center py-8">No historical data available for charting.</p>
                )}
              </div>
            </section>

            {/* News & Sentiment Analysis */}
            <section className="mb-12 animate-slide-up">
              <h2 className="text-3xl font-bold mb-6 text-cyan-blue-300 drop-shadow">📰 News & Sentiment Analysis</h2>
              <div className="bg-charcoal-800 p-6 rounded-xl shadow-xl glass-effect border border-cyan-blue-200/20">
                {newsSentiment && newsSentiment.length > 0 ? (
                  <ul className="space-y-4">
                    {newsSentiment.map((newsItem, index) => (
                      <li key={index} className="pb-4 border-b border-cyan-blue-200/10 last:border-b-0">
                        <a
                          href={newsItem.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-lg font-semibold text-pink-300 hover:underline block mb-1"
                        >
                          {newsItem.title}
                        </a>
                        <p className="text-sm text-gray-400 mb-2">{newsItem.description}</p>
                        <div className="flex items-center text-sm">
                          <span className={`${getSentimentColor(newsItem.sentiment)} font-medium mr-4`}>
                            Sentiment: {newsItem.sentiment}
                          </span>
                          <span className="text-gray-500">
                            Source: {newsItem.source} | Published: {newsItem.publishedAt}
                          </span>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-light-gray text-center py-4">No news or sentiment data available.</p>
                )}
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
};

export default Dashboard;