// src/components/dashboard/MarketOverview.tsx
// This component would display global market indices and commodities.
// Its content is currently in Dashboard.tsx under "Global Market Overview".

import React from 'react';

interface MarketOverviewProps {
  data: any[]; // Data for market indices/commodities
}

const MarketOverview: React.FC<MarketOverviewProps> = ({ data }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
      {data.map((item, index) => (
        <div key={index} className="p-4 rounded-xl card-neumorphic flex items-center space-x-3 transition-transform duration-200 hover:scale-[1.03] border border-cyan-blue-200/10">
          <img src={item.img} alt={item.name} className="w-10 h-10 rounded-full object-cover shadow-sm" />
          <div>
            <p className="text-sm font-semibold text-light-gray leading-tight">{item.name}</p>
            <p className="text-lg font-bold text-cyan-blue-300">{item.value}</p>
            <p className={`text-xs ${item.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>{item.change}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MarketOverview;