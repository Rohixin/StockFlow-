// my-stock-dashboard/src/components/charts/StockChart.tsx
'use client'; // This component must be client-side

import React, { useMemo } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer,
  AreaChart, Area, ReferenceLine
} from 'recharts';

interface StockDataPoint {
  Date: string; // This will now be a full timestamp string (e.g., "2025-06-07 14:30:00")
  Open: number;
  High: number;
  Low: number;
  Close: number;
  Volume: number;
}

interface ForecastDataPoint {
  ds: string;
  yhat: number;
  yhat_lower: number;
  yhat_upper: number;
}

interface StockChartProps {
  data: StockDataPoint[];
  compareData?: StockDataPoint[] | null;
  forecastData?: ForecastDataPoint[] | null;
  indicators?: string[];
  mainSymbol: string;
  compareSymbol?: string;
  darkMode: boolean;
}

const StockChart: React.FC<StockChartProps> = ({
  data,
  compareData,
  forecastData,
  indicators,
  mainSymbol,
  compareSymbol,
  darkMode
}) => {

  // Prepare data for comparison chart, normalizing if needed (for different price ranges)
  const compareChartData = useMemo(() => {
    if (!data || !compareData) return [];

    // Simple normalization for visualization: scale comparison data to main data's range
    // This allows different stocks to be visually compared on the same Y-axis
    const mainPrices = data.map(d => d.Close);
    const comparePrices = compareData.map(d => d.Close);

    const mainMax = Math.max(...mainPrices);
    const mainMin = Math.min(...mainPrices);
    const compareMax = Math.max(...comparePrices);
    const compareMin = Math.min(...comparePrices);

    // Avoid division by zero if compareData has no price range
    if (compareMax === compareMin) {
        // If compare data is flat, just use a default scale or return only main data
        return data.map((d, i) => ({
            Date: d.Date,
            [mainSymbol]: d.Close,
        })).filter(d => d[mainSymbol] !== undefined);
    }

    const scaleFactor = (mainMax - mainMin) / (compareMax - compareMin);
    const offset = mainMin - (compareMin * scaleFactor);

    return data.map((d, i) => {
      const comparePoint = compareData[i];
      if (comparePoint) {
        return {
          Date: d.Date,
          [mainSymbol]: d.Close,
          [compareSymbol || 'Compare']: (comparePoint.Close * scaleFactor) + offset // Scaled value
        };
      }
      return {
        Date: d.Date,
        [mainSymbol]: d.Close
      };
    }).filter(d => d[mainSymbol] !== undefined); // Ensure valid data points
  }, [data, compareData, mainSymbol, compareSymbol]);


  const textColor = darkMode ? '#E0E0E0' : '#333333';
  const gridColor = darkMode ? '#444444' : '#E0E0E0';
  const mainLineColor = darkMode ? '#93C5FD' : '#2563EB'; // Blue for main
  const compareLineColor = darkMode ? '#F472B6' : '#EC4899'; // Pink for comparison
  const forecastLineColor = darkMode ? '#22C55E' : '#10B981'; // Green for forecast
  const forecastUncertaintyColor = darkMode ? '#22C55E' : '#10B981'; // Same as forecast line for consistency


  return (
    <div className="w-full flex flex-col space-y-8">

      {/* 1. Historical Price Chart (Actual Price) - NOTE: Volume Line REMOVED FROM HERE */}
      <div className="flex flex-col">
        <h3 className="text-xl font-bold mb-4 text-cyan-blue-300">Historical Price: {mainSymbol} {compareSymbol && `vs. ${compareSymbol}`}</h3>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart
            data={compareData ? compareChartData : data}
            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
            <XAxis
              dataKey="Date"
              // Updated tickFormatter to display both date and time for intraday data
              tickFormatter={(tick) => {
                  const d = new Date(tick);
                  if (isNaN(d.getTime())) return tick; // Return original if not a valid date
                  if (tick.includes(' ')) { // If it contains space, assume it's a full timestamp
                      return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                  }
                  return d.toLocaleDateString(); // Otherwise, just date for daily data
              }}
              stroke={textColor}
            />
            <YAxis stroke={textColor} domain={['dataMin', 'dataMax']} />
            <Tooltip
              contentStyle={{ backgroundColor: darkMode ? '#334155' : '#FFFFFF', border: 'none', borderRadius: '8px', color: textColor }}
              labelFormatter={(label) => `Date: ${new Date(label).toLocaleString()}`} // Use toLocaleString for full date/time
            />
            <Legend wrapperStyle={{ color: textColor }} />

            <Line
              type="monotone"
              dataKey={compareData ? mainSymbol : "Close"}
              stroke={mainLineColor}
              strokeWidth={2}
              dot={false}
              name={mainSymbol}
            />

            {compareData && compareSymbol && (
              <Line
                type="monotone"
                dataKey={compareSymbol}
                stroke={compareLineColor}
                strokeWidth={2}
                dot={false}
                name={`${compareSymbol} (Scaled)`}
              />
            )}
          </LineChart>
        </ResponsiveContainer>

        {/* Dedicated Volume Chart below the price chart */}
        <ResponsiveContainer width="100%" height={100}>
            <AreaChart
                data={data}
                margin={{ top: 0, right: 30, left: 20, bottom: 5 }}
            >
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
                <XAxis
                    dataKey="Date"
                    // Updated tickFormatter for volume chart too
                    tickFormatter={(tick) => {
                        const d = new Date(tick);
                        if (isNaN(d.getTime())) return tick;
                        if (tick.includes(' ')) {
                            return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                        }
                        return d.toLocaleDateString();
                    }}
                    stroke={textColor}
                />
                <YAxis orientation="right" stroke={textColor} tickFormatter={(tick) => `${(tick / 1000000).toFixed(0)}M`} />
                <Tooltip
                    contentStyle={{ backgroundColor: darkMode ? '#334155' : '#FFFFFF', border: 'none', borderRadius: '8px', color: textColor }}
                    labelFormatter={(label) => `Date: ${new Date(label).toLocaleString()}`}
                />
                <Area type="monotone" dataKey="Volume" stroke={mainLineColor} fill={mainLineColor} fillOpacity={0.3} name="Volume" />
            </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* 2. Forecast Price Chart */}
      {forecastData && forecastData.length > 0 && (
        <div className="flex flex-col">
          <h3 className="text-xl font-bold mb-4 text-cyan-blue-300">AI Model Forecast: {mainSymbol} ({forecastData.length / 365} Years)</h3>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart
              data={forecastData}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis
                dataKey="ds"
                // Updated tickFormatter for forecast chart too (likely only dates here)
                tickFormatter={(tick) => new Date(tick).toLocaleDateString()}
                stroke={textColor}
              />
              <YAxis stroke={textColor} domain={['dataMin', 'dataMax']} />
              <Tooltip
                contentStyle={{ backgroundColor: darkMode ? '#334155' : '#FFFFFF', border: 'none', borderRadius: '8px', color: textColor }}
                labelFormatter={(label) => `Date: ${new Date(label).toLocaleDateString()}`}
              />
              <Legend wrapperStyle={{ color: textColor }} />

              <Line
                type="monotone"
                dataKey="yhat"
                stroke={forecastLineColor}
                strokeWidth={2}
                dot={false}
                name="Predicted Close"
              />

              <Line
                type="monotone"
                dataKey="yhat_upper"
                stroke={forecastUncertaintyColor}
                strokeDasharray="3 3"
                strokeWidth={1}
                dot={false}
                name="Upper Bound"
                opacity={0.7}
              />
              <Line
                type="monotone"
                dataKey="yhat_lower"
                stroke={forecastUncertaintyColor}
                strokeDasharray="3 3"
                strokeWidth={1}
                dot={false}
                name="Lower Bound"
                opacity={0.7}
              />

              {data && data.length > 0 && (
                <ReferenceLine
                  y={data[data.length - 1].Close}
                  label={{
                    value: `Last Actual: ${data[data.length - 1].Close.toFixed(2)}`,
                    position: 'insideBottomRight',
                    fill: textColor,
                    fontSize: 12
                  }}
                  stroke="#FFBB28"
                  strokeDasharray="3 3"
                />
              )}

            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Note for Interactivity */}
      <p className="text-gray-400 text-sm text-center mt-8 p-4 bg-charcoal-800 rounded-lg">
        **Regarding Zoom & Pan:** Current charts are good for visualization. For advanced interactive features like click-and-drag zoom/pan, crosshairs, and more sophisticated financial indicators, consider libraries specifically designed for financial charting such as <a href="https://tradingview.github.io/lightweight-charts/" target="_blank" rel="noopener noreferrer" className="text-cyan-blue-300 hover:underline">Lightweight Charts by TradingView</a> or <a href="https://rrag.github.io/react-financial-charts/" target="_blank" rel="noopener noreferrer" className="text-cyan-blue-300 hover:underline">react-financial-charts</a>. Implementing these features directly with Recharts for financial use cases can be complex.
      </p>
    </div>
  );
};

export default StockChart;