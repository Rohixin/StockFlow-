// src/components/ui/Card.tsx
import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', ...props }) => {
  return (
    <div
      className={`p-6 rounded-xl card-neumorphic border border-cyan-blue-200/10 ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};

export default Card;