// src/components/ui/Button.tsx
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ children, className = '', ...props }) => {
  return (
    <button
      className={`py-3 px-6 rounded-lg text-white font-semibold neumorphic-button bg-gradient-to-r from-cyan-blue-300 to-pink-300 hover:from-cyan-blue-400 hover:to-pink-400 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-cyan-blue-300 focus:ring-opacity-75 ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;