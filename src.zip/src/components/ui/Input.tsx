// src/components/ui/Input.tsx
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  className?: string;
}

const Input: React.FC<InputProps> = ({ className = '', ...props }) => {
  return (
    <input
      className={`w-full p-3 rounded-lg neumorphic-input bg-charcoal-800 text-light-gray placeholder-gray-500 focus:ring-2 focus:ring-cyan-blue-300 focus:border-transparent transition duration-200 ease-in-out ${className}`}
      {...props}
    />
  );
};

export default Input;