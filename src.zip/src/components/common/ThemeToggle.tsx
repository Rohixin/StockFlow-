// src/components/common/ThemeToggle.tsx
'use client';

import React, { useState, useEffect } from 'react';

interface ThemeToggleProps {
  darkMode: boolean;
  setDarkMode: (value: boolean) => void;
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ darkMode, setDarkMode }) => {
  return (
    <div className="flex items-center justify-between p-3 rounded-xl bg-dark-navy card-neumorphic border border-cyan-blue-200/10">
      <span className="text-light-gray text-base font-medium mr-2">{darkMode ? '🌙 Dark Mode' : '🌞 Light Mode'}</span>
      <label htmlFor="theme-toggle" className="toggle-switch">
        <input
          id="theme-toggle"
          type="checkbox"
          checked={darkMode}
          onChange={() => setDarkMode(!darkMode)}
        />
        <span className="toggle-slider"></span>
      </label>
    </div>
  );
};

export default ThemeToggle;