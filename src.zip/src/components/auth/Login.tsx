// my-stock-dashboard/src/components/auth/Login.tsx

'use client'; // This component needs to run on the client side

import React, { useState } from 'react';

interface LoginProps {
  onLoginSuccess: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // --- Mock Login Logic ---
    // For now, accept any non-empty username/password, or specific ones for testing
    if (username === 'user' && password === 'password') { // You can change these credentials
      onLoginSuccess();
    } else if (username.length > 0 && password.length > 0) {
      // If you want to allow any non-empty input for ease of testing
      onLoginSuccess();
    }
    else {
      setError('Invalid username or password.');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-dark-navy to-charcoal-800">
      <div className="bg-charcoal-800 p-8 rounded-xl shadow-2xl glass-effect border border-cyan-blue-200/30 w-full max-w-md text-light-gray animate-fade-in-up">
        <h2 className="text-3xl font-bold mb-8 text-center text-cyan-blue-300 drop-shadow">Welcome! Please Login</h2>
        {error && <p className="text-red-500 text-center mb-4">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-cyan-blue-200 mb-2">Username</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              className="w-full p-3 rounded-lg neumorphic-input bg-dark-navy text-light-gray placeholder-gray-500 text-base focus:ring-2 focus:ring-pink-300 focus:border-transparent transition-all duration-200"
              required
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-cyan-blue-200 mb-2">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full p-3 rounded-lg neumorphic-input bg-dark-navy text-light-gray placeholder-gray-500 text-base focus:ring-2 focus:ring-pink-300 focus:border-transparent transition-all duration-200"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full py-3.5 rounded-lg text-white font-semibold neumorphic-button bg-gradient-to-r from-cyan-blue-300 to-pink-300 hover:from-cyan-blue-400 hover:to-pink-400 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-cyan-blue-300 focus:ring-opacity-75"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;