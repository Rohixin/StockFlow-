// src/components/news/NewsArticleCard.tsx
// This component displays a single news article with sentiment.
// Its content is currently within Dashboard.tsx under "Recent News Sentiment".

import React from 'react';

interface NewsArticleCardProps {
  article: {
    title: string;
    url: string;
    description: string;
    sentiment: 'Positive' | 'Negative' | 'Neutral';
    score: number;
    source: string;
    publishedAt: string;
  };
}

const NewsArticleCard: React.FC<NewsArticleCardProps> = ({ article }) => {
  const sentimentColorClass = article.sentiment === 'Positive' ? 'text-green-500' : article.sentiment === 'Negative' ? 'text-red-500' : 'text-gray-400';
  const sentimentImageText = article.sentiment === 'Positive' ? 'Uptrend%0A%F0%9F%93%88' : article.sentiment === 'Negative' ? 'Downtrend%0A%F0%9F%93%89' : 'Neutral%0A%F0%9F%93%8A';
  const sentimentImageColor = article.sentiment === 'Positive' ? '22c55e' : article.sentiment === 'Negative' ? 'ef4444' : '6b7280'; // Hex colors for placehold.co

  return (
    <div className="p-6 rounded-xl card-neumorphic hover:shadow-xl transition-all duration-300 border border-cyan-blue-200/10 flex flex-col">
      <img
        src={`https://placehold.co/100x100/${sentimentImageColor}/ffffff/png?text=${sentimentImageText}`}
        alt={`${article.sentiment} sentiment`}
        className="w-24 h-24 rounded-full mx-auto mb-4 object-cover border-2 border-charcoal-900 shadow-md"
      />
      <h3 className="text-lg font-semibold text-cyan-blue-300 mb-2 leading-tight">{article.title}</h3>
      <p className={`text-sm font-bold mb-2 ${sentimentColorClass}`}>
        Sentiment: {article.sentiment} (Score: {article.score.toFixed(2)})
      </p>
      <p className="text-xs text-gray-500 mb-2">Source: {article.source} | Published: {article.publishedAt}</p>
      <p className="text-sm text-light-gray mb-4 line-clamp-3 flex-grow">{article.description}</p>
      <a href={article.url} target="_blank" rel="noopener noreferrer" className="text-pink-300 hover:underline text-sm mt-auto self-start">Read More &rarr;</a>
    </div>
  );
};

export default NewsArticleCard;