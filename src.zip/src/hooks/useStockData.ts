// src/hooks/useStockData.ts
import { useState, useEffect } from 'react';

// Define interfaces for your data structures (better than `any`)
interface StockDataPoint {
  Date: string;
  Open: number;
  High: number;
  Low: number;
  Close: number;
  Volume: number;
}

interface ForecastDataPoint {
  ds: string;
  yhat: number;
  yhat_lower?: number;
  yhat_upper?: number;
}

interface NewsArticle {
  title: string;
  url: string;
  description: string;
  sentiment: 'Positive' | 'Negative' | 'Neutral';
  score: number;
  source: string;
  publishedAt: string;
}

interface UseStockDataResult {
  stockData: StockDataPoint[] | null;
  forecastData: ForecastDataPoint[] | null;
  newsSentiment: NewsArticle[] | null;
  loading: boolean;
  error: string | null;
  analyzeStock: (symbol: string, forecastYears: number, modelChoice: string) => Promise<void>;
}

// In a real app, these would call your Next.js API routes (e.g., /api/stock/[symbol])
const fetchMockStockData = async (symbol: string): Promise<StockDataPoint[]> => {
  // Your mock data generation logic from Dashboard.tsx
  const today = new Date();
  return Array.from({ length: 365 * 5 }, (_, i) => {
    const date = new Date(today);
    date.setDate(today.getDate() - (365 * 5 - 1) + i);
    const basePrice = 1500;
    const close = basePrice + (i / (365 * 5)) * 1000 + Math.sin(i / 15) * 50 + Math.cos(i / 60) * 100 + (Math.random() * 40 - 20);
    const open = close + (Math.random() * 20 - 10);
    const high = Math.max(open, close) + (Math.random() * 15);
    const low = Math.min(open, close) - (Math.random() * 15);
    return {
      Date: date.toISOString().split('T')[0],
      Open: parseFloat(open.toFixed(2)),
      High: parseFloat(high.toFixed(2)),
      Low: parseFloat(low.toFixed(2)),
      Close: parseFloat(close.toFixed(2)),
      Volume: Math.floor(Math.random() * 4000000 + 1000000)
    };
  });
};

const generateMockForecast = async (model: string, data: StockDataPoint[], years: number): Promise<ForecastDataPoint[]> => {
  // Your mock forecast generation logic from Dashboard.tsx
  const lastDataPoint = data[data.length - 1];
  if (!lastDataPoint) return [];
  const lastClose = lastDataPoint.Close;
  return Array.from({ length: years * 365 }, (_, i) => {
    const date = new Date(lastDataPoint.Date);
    date.setDate(date.getDate() + i + 1);
    const yhat = lastClose * (1 + (0.00005 * i) + (Math.random() * 0.0002 - 0.0001) * i) + (Math.random() * 10 - 5);
    const uncertainty = i * 0.005 + 10;
    const yhat_lower = yhat - (Math.random() * uncertainty);
    const yhat_upper = yhat + (Math.random() * uncertainty);
    return {
      ds: date.toISOString().split('T')[0],
      yhat: parseFloat(yhat.toFixed(2)),
      yhat_lower: parseFloat(yhat_lower.toFixed(2)),
      yhat_upper: parseFloat(yhat_upper.toFixed(2))
    };
  });
};

const fetchMockNewsSentiment = async (companyName: string): Promise<NewsArticle[]> => {
  // Your mock news sentiment logic from Dashboard.tsx
  return [
    { title: `${companyName} Q1 Earnings Beat Expectations`, url: '#', description: `Company ${companyName} reports strong first quarter results, surpassing analyst forecasts.`, sentiment: 'Positive', score: 0.8, source: 'Financial Times', publishedAt: '2025-06-05' },
    { title: `${companyName} Faces Regulatory Scrutiny`, url: '#', description: `New government regulations may significantly impact ${companyName}'s future operations.`, sentiment: 'Negative', score: -0.6, source: 'Reuters', publishedAt: '2025-06-04' },
  ];
};


const useStockData = (): UseStockDataResult => {
  const [stockData, setStockData] = useState<StockDataPoint[] | null>(null);
  const [forecastData, setForecastData] = useState<ForecastDataPoint[] | null>(null);
  const [newsSentiment, setNewsSentiment] = useState<NewsArticle[] | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const analyzeStock = async (symbol: string, forecastYears: number, modelChoice: string) => {
    setLoading(true);
    setError(null);
    try {
      // In a real app, replace fetchMockStockData with calls to your API routes:
      // const stockResponse = await fetch(`/api/stock/${symbol}`);
      // const stockData = await stockResponse.json();
      const stockData = await fetchMockStockData(symbol);
      setStockData(stockData);

      // In a real app, replace generateMockForecast with calls to your API routes:
      // const forecastResponse = await fetch(`/api/forecast`, { method: 'POST', body: JSON.stringify({ model: modelChoice, data: stockData, years: forecastYears }) });
      // const forecastData = await forecastResponse.json();
      const forecastData = await generateMockForecast(modelChoice, stockData, forecastYears);
      setForecastData(forecastData);

      // In a real app, replace fetchMockNewsSentiment with calls to your API routes:
      // const newsResponse = await fetch(`/api/news/${symbol.split('.')[0]}`);
      // const newsSentiment = await newsResponse.json();
      const newsSentiment = await fetchMockNewsSentiment(symbol.split('.')[0]);
      setNewsSentiment(newsSentiment);

    } catch (err: any) {
      setError(err.message || 'An unknown error occurred during analysis.');
      console.error(err);
      setStockData(null);
      setForecastData(null);
      setNewsSentiment(null);
    } finally {
      setLoading(false);
    }
  };

  return { stockData, forecastData, newsSentiment, loading, error, analyzeStock };
};

export default useStockData;