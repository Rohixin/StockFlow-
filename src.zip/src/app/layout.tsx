// src/app/layout.tsx
import './globals.css'; // This imports your global CSS, which includes Tailwind directives
import { Inter } from 'next/font/google'; // Correct import for Inter font

// Initialize the Inter font for use with Next.js font optimization
const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'NeoFinance Stock Dashboard',
  description: 'Your advanced financial analysis platform',
};

export default function RootLayout({
  children, // This is the correct type for children
}: {
  children: React.ReactNode; // React.ReactNode is correctly typed if React types are installed
}) {
  return (
    // The 'dark' class on the html tag activates Tailwind's dark mode.
    // All components within `children` will inherit dark mode styles
    <html lang="en" className="dark">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}