// src/app/api/stocks/route.ts
// This is a Next.js API Route (server-side code) using the App Router convention.
// It securely fetches data from Google Sheets using a service account.

import { google } from 'googleapis';
import { NextResponse } from 'next/server'; // Used for returning API responses

// Define an interface for the expected structure of the service account credentials
interface ServiceAccountCredentials {
  client_email: string;
  private_key: string;
  [key: string]: any; // Allows other properties to exist
}

// --- Helper function to initialize Google Sheets API client ---
async function getGoogleSheetsClient() {
  const serviceAccountCredentialsString = process.env.GOOGLE_SERVICE_ACCOUNT_CREDENTIALS;
  const spreadsheetId = process.env.GOOGLE_SHEET_ID;

  if (!serviceAccountCredentialsString) {
    console.error('SERVER ERROR: GOOGLE_SERVICE_ACCOUNT_CREDENTIALS is NOT defined in .env.local');
    throw new Error('Google Sheets API credentials are not configured. Please ensure GOOGLE_SERVICE_ACCOUNT_CREDENTIALS is set in your .env.local file.');
  }
  if (!spreadsheetId) {
    console.error('SERVER ERROR: GOOGLE_SHEET_ID is NOT defined in .env.local');
    throw new Error('Google Sheet ID is not configured. Please ensure GOOGLE_SHEET_ID is set in your .env.local file.');
  }

  let credentials: ServiceAccountCredentials;
  try {
    credentials = JSON.parse(serviceAccountCredentialsString) as ServiceAccountCredentials;
  } catch (parseError: any) {
    console.error('SERVER ERROR: Failed to parse GOOGLE_SERVICE_ACCOUNT_CREDENTIALS JSON. Check format.', parseError.message);
    throw new Error('Invalid Google Service Account Credentials JSON format. Ensure it is a single-line, valid JSON string.');
  }

  if (!credentials.client_email || typeof credentials.client_email !== 'string') {
    const errorMsg = 'Service account client_email is missing or not a string after parsing credentials.';
    console.error('SERVER ERROR:', errorMsg, { client_email: credentials.client_email });
    throw new Error(errorMsg);
  }
  if (!credentials.private_key || typeof credentials.private_key !== 'string') {
    const errorMsg = 'Service account private_key is missing or not a string after parsing credentials.';
    console.error('SERVER ERROR:', errorMsg, { private_key: credentials.private_key ? '***hidden***' : 'missing' });
    throw new Error(errorMsg);
  }

  const auth = new google.auth.JWT(
    credentials.client_email,
    undefined, // Using 'undefined' as the keyFile path, as the key is passed directly
    credentials.private_key,
    ['https://www.googleapis.com/auth/spreadsheets.readonly']
  );

  await auth.authorize();
  return google.sheets({ version: 'v4', auth });
}

// --- Next.js API Route GET handler ---
export async function GET(request: Request) {
  try {
    const sheets = await getGoogleSheetsClient();
    const spreadsheetId = process.env.GOOGLE_SHEET_ID!;

    const range = 'StockData!A1:Z'; // IMPORTANT: Match your actual Google Sheet tab name here

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range,
    });

    const rows = response.data.values;

    if (!rows || rows.length <= 1) {
      console.log('API RESPONSE: No stock data found or only headers present in Google Sheet.');
      return NextResponse.json({ stocks: [] }, { status: 200 }); // Return 200 with empty array if no actual data
    }

    const headers = rows[0];
    const data = rows.slice(1).map(row => {
      const obj: { [key: string]: any } = {};
      headers.forEach((header, index) => {
        const cleanHeader = header.trim().replace(/\s+/g, '');
        let value: any = row[index];

        if (typeof value === 'string' && value.trim() !== '') {
          const numValue = parseFloat(value.replace(/,/g, ''));
          if (!isNaN(numValue)) {
            value = numValue;
          }
        }
        obj[cleanHeader] = value;
      });
      return obj;
    });

    console.log(`API RESPONSE: Successfully fetched ${data.length} stock entries from Google Sheet.`);
    return NextResponse.json({ stocks: data }, { status: 200 });

  } catch (error: any) {
    console.error('SERVER ERROR: Error in /api/stocks GET handler:', error.message, error.stack);

    const clientErrorMessage = process.env.NODE_ENV === 'development'
      ? `Failed to fetch stock data: ${error.message}. Check server logs, .env.local, and sheet name ('StockData').`
      : 'Internal Server Error: Could not fetch stock data.';

    return NextResponse.json({ error: clientErrorMessage }, { status: 500 });
  }
}

