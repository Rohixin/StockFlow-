// my-stock-dashboard/src/app/page.tsx

'use client'; 

import { useState, useEffect } from 'react';
// CORRECTED import paths:
import Login from '../components/auth/Login'; 
import Dashboard from '../components/dashboard/Dashboard'; 

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false); 

  useEffect(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('isLoggedIn') === 'true') {
      setIsLoggedIn(true);
    }
  }, []);

  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
    if (typeof window !== 'undefined') {
      localStorage.setItem('isLoggedIn', 'true');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('isLoggedIn');
    }
  };

  return (
    <div className="min-h-screen">
      {isLoggedIn ? (
        <Dashboard onLogout={handleLogout} />
      ) : (
        <Login onLoginSuccess={handleLoginSuccess} />
      )}
    </div>
  );
}